import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';

import CONTACT_NAME_FIELD from '@salesforce/schema/Contact.Name';
import STAGE_FIELD from '@salesforce/schema/Opportunity.StageName';
import OPPORTUNITY_OBJECT from '@salesforce/schema/Opportunity';
import { CloseActionScreenEvent } from 'lightning/actions';

import createOpportunity from '@salesforce/apex/OpportunityHelper.createOpportunity';

export default class ContactQuickAction extends LightningElement {
    @api recordId;

    contactName = '';
    contactId = '';
    oppName = '';
    stage = '';
    closeDate = '';
    stageOptions = [];

    connectedCallback() {
        console.log('Quick Action Contact recordId:', this.recordId);
    }

    // Fetch Contact Name using Lightning Data Service
    @wire(getRecord, { recordId: '$recordId', fields: [CONTACT_NAME_FIELD] })
    wiredContact({ data, error }) {
        if (data) {
            console.log('Contact data:', data);
            this.contactName = data.fields.Name.value;
            this.contactId = this.recordId;
        } else if (error) {
            console.error('Error fetching contact:', error);
        }
    }

    // Get Opportunity object metadata for default record type
    @wire(getObjectInfo, { objectApiName: OPPORTUNITY_OBJECT })
    opportunityMetadata;

    // Get Stage picklist values for Opportunity
    @wire(getPicklistValues, {
        recordTypeId: '$opportunityMetadata.data.defaultRecordTypeId',
        fieldApiName: STAGE_FIELD
    })
    wiredStageValues({ data, error }) {
        if (data) {
            this.stageOptions = data.values.map(option => ({
                label: option.label,
                value: option.value
            }));
        } else if (error) {
            console.error('Error loading stage picklist:', error);
        }
    }

    handleChange(event) {
        const field = event.target.dataset.id;
        this[field] = event.target.value;
    }

  async handleSubmit() {
    if (!this.contactId || !this.oppName || !this.stage || !this.closeDate) {
        alert('Please fill all required fields.');
        return;
    }

    try {
        await createOpportunity({
            contactId: this.contactId,
            name: this.oppName,
            stage: this.stage,
            closeDate: this.closeDate
        });

        alert('Opportunity created successfully!');

        // Close the quick action panel
        this.dispatchEvent(new CloseActionScreenEvent());
    } catch (error) {
        console.error('Error creating opportunity:', error);
        alert('Error: ' + (error?.body?.message || 'Unknown error'));
    }
}
}